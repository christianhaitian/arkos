#!/bin/bash
sudo sed -i "/SuspendState\=/c\SuspendState\=mem" /etc/systemd/sleep.conf
cp -f /usr/local/bin/"Sleep - Switch to Light sleep support.sh" /opt/system/Advanced/.
sudo rm /opt/system/Advanced/"Sleep - Switch to Deep sleep support.sh"
printf "\n\n\e[32mSleep mode has been switch to deep mode.  Restarting emulationstation now...\n"
printf "\033[0m"
sleep 3
sudo systemctl restart emulationstation
printf "\033c" >> /dev/tty1
