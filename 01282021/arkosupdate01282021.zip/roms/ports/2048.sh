#!/bin/bash

/usr/local/bin/retroarch -L /home/ark/.config/retroarch/cores/2048_libretro.so