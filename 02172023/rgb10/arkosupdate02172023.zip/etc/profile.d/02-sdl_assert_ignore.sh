# When joysticks connect and disconnects, it can cause 
# assertion warning which can break UIs like Emulationstation
export SDL_ASSERT="always_ignore"
