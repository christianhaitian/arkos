#!/bin/bash
cd /roms/ports/soniccd
sudo systemctl start soniccdhotkey.service
SDL_GAMECONTROLLERCONFIG="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b7,x:b3,y:b2,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b1,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux," soniccd
sudo systemctl stop soniccdhotkey.service