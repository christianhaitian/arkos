#!/bin/bash
cd /roms/ports/soniccd
sudo systemctl start soniccdhotkey.service
SDL_GAMECONTROLLERCONFIG="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,guide:b12,leftstick:b14,lefttrigger:b13,rightstick:b15,righttrigger:b16,start:b17,platform:Linux," soniccd
sudo systemctl stop soniccdhotkey.service