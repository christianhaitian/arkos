#!/bin/bash
cd /opt/cdogs/data
sudo systemctl start cdogshotkey.service
./cdogs-sdl
sudo systemctl stop cdogshotkey.service