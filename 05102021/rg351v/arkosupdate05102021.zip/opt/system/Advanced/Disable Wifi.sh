#!/bin/bash
sudo modprobe -r mt7601u
sudo sed -i '$ablacklist mt7601u' /etc/modprobe.d/blacklist.conf
# sudo nmcli r wifi off
printf "\n\n\n\e[32mWifi has been disabled.\n"
sleep 1
