#!/bin/bash
sudo modprobe -i mt7601u
sudo sed -i '/blacklist mt7601u/d' /etc/modprobe.d/blacklist.conf
#sudo nmcli r wifi on
printf "\n\n\n\e[32mWifi has been enabled.\n"
sleep 1

