#!/bin/bash

cd /opt/hcl
sudo systemctl start hclhotkey
SDL_GAMECONTROLLERCONFIG="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b6,start:b7,rightx:a2,righty:a3,righttrigger:b11,platform:Linux," ./hcl
sudo systemctl stop hclhotkey
