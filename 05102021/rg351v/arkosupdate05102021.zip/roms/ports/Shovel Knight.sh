#!/bin/bash
cd /roms/ports/shovelknight/32

export LIBGL_NOBANNER=1
export LIBGL_ES=2
export LIBGL_GL=21
export LIBGL_FB=4
export BOX86_LOG=0
export LD_LIBRARY_PATH=/opt/box86/lib:/usr/lib32:/opt/box86/native
export BOX86_LD_LIBRARY_PATH=/opt/box86/lib:/opt/box86/native:/usr/lib32/:./:lib/:lib32/:x86/
export BOX86_DYNAREC=1
export SDL_GAMECONTROLLERCONFIG="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,y:b3,x:b2,start:b6,back:b7,dpup:h0.1,dpleft:h0.8,dpdown:h0.4,dpright:h0.2,leftshoulder:b4,rightshoulder:b5,leftstick:b8,guide:b9,leftx:a0~,lefty:a1~,rightx:a2,righty:a3,lefttrigger:b10,righttrigger:b11,platform:Linux,"
sudo systemctl start skhotkey.service
/opt/box86/box86 ShovelKnight
sudo systemctl stop skhotkey.service
