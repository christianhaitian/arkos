#!/bin/bash

cd /opt/hcl
sudo systemctl start hclhotkey
SDL_GAMECONTROLLERCONFIG="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,back:b17,leftstick:b14,lefttrigger:b13,rightstick:b15,righttrigger:b16,start:b12,platform:Linux," ./hcl
sudo systemctl stop hclhotkey
