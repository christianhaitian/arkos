#!/bin/bash
cd /roms/ports/shovelknight/32

export LIBGL_NOBANNER=1
export LIBGL_ES=2
export LIBGL_GL=21
export LIBGL_FB=4
export BOX86_LOG=0
export LD_LIBRARY_PATH=/opt/box86/lib:/usr/lib32:/opt/box86/native
export BOX86_LD_LIBRARY_PATH=/opt/box86/lib:/opt/box86/native:/usr/lib32/:./:lib/:lib32/:x86/
export BOX86_DYNAREC=1
export SDL_GAMECONTROLLERCONFIG="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,back:b12,leftstick:b14,lefttrigger:b13,rightstick:b15,righttrigger:b16,start:b17,platform:Linux,"
sudo systemctl start skhotkey.service
/opt/box86/box86 ShovelKnight
sudo systemctl stop skhotkey.service
