#!/bin/bash

cd /opt/hcl
sudo systemctl start hclhotkey
SDL_GAMECONTROLLERCONFIG="190000004b4800000010000000010000,GO-Advance Gamepad,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,leftstick:b12,back:b15,lefttrigger:b11,rightstick:b13,righttrigger:b14,start:b10,platform:Linux," ./hcl
sudo systemctl stop hclhotkey
