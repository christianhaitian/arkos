#!/bin/bash
cd /roms/ports/shovelknight/32

export LIBGL_NOBANNER=1
export LIBGL_ES=2
export LIBGL_GL=21
export LIBGL_FB=4
export BOX86_LOG=0
export LD_LIBRARY_PATH=/opt/box86/lib:/usr/lib32:/opt/box86/native
export BOX86_LD_LIBRARY_PATH=/opt/box86/lib:/opt/box86/native:/usr/lib32/:./:lib/:lib32/:x86/
export BOX86_DYNAREC=1
export SDL_GAMECONTROLLERCONFIG="190000004b4800000010000000010000,GO-Advance Gamepad,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,leftstick:b12,back:b10,lefttrigger:b11,rightstick:b13,righttrigger:b14,start:b15,platform:Linux,"
sudo systemctl start skhotkey.service
/opt/box86/box86 ShovelKnight
sudo systemctl stop skhotkey.service
