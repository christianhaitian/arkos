#!/bin/bash

################################################################################################
# Thanks to tomtomp for the work on providing experimental resources for this.                 #
# https://github.com/anaximan/rg353v-linux/blob/main/patches/sdl2-patch-0004-touch-mouse.patch #
# https://github.com/anaximan/RG353VKernel                                                     #
# https://github.com/libretro/RetroArch/pull/15282                                             #
# https://github.com/anaximan/scummvm                                                          #
################################################################################################

. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to enable experimental touch support?\n"
printf "\nPress A to continue.  Press B to exit.\n"

while true
do
   Test_Button_A
   if [ "$?" -eq "10" ]; then
      if [ ! -z "$(grep "RG353M" /home/ark/.config/.DEVICE | tr -d '\0')" ]; then
        DEVICE="rg353m"
      elif [ ! -z "$(grep "RG353V" /home/ark/.config/.DEVICE | tr -d '\0')" ]; then
        DEVICE="rg353v"
      else
        printf "\nThis does not seem to be a RG353M or RG353V device."
        printf "\nThis features is only available for these 2 devices."
        sleep 15
        exit 0
      fi

      # Copy touch enabled kernel and dtb to the boot partition overwriting the existing ones
      sudo cp -fv /usr/local/bin/experimental/Image.touch /boot/Image
      sudo cp -fv /usr/local/bin/experimental/rk3566-${DEVICE}.dtb.touch /boot/rk3566-OC.dtb

      # Copy updated touch enabled aarch64 libSDL
      sudo cp -fv /usr/local/bin/experimental/libSDL2-2.0.so.0.2600.5.touch /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2600.5

      # Make touch enabled emulators available
      cp -fv /opt/retroarch/bin/retroarch.touch /opt/retroarch/bin/retroarch
      mv -fv /opt/scummvm/ /opt/scummvm.orig/
      mv -fv /opt/scummvm.touch/ /opt/scummvm/

      # Replace Enable script with Disable script in Options/Advanced section
      sudo rm -f /opt/system/Advanced/"Enable Experimental Touch support.sh"
      cp -f /usr/local/bin/experimental/"Disable Experimental Touch support.sh" /opt/system/Advanced/.

      # Fix some exit hotkey demons to account for additional event input
      sudo sed -i '/\/dev\/input\/event3/s//\/dev\/input\/event4/g' /usr/local/bin/*.py

      # Reboot to activate
      printf "\nExperimental touch support has been enabled.  Rebooting shortly to activate it."
      printf "\nIf Experimental touch support causes issues, you can revert these changes"
      printf "\nby going to Options/Advanced and selecting Disable Experimental Touch support."
      sleep 15
      sudo reboot
   fi

   Test_Button_B
   if [ "$?" -eq "10" ]; then
      printf "\nExiting without enabling experimental touch support."
      sleep 3
      exit 0
   fi
done
