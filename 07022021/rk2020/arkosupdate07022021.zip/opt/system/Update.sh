#!/bin/bash

LOG_FILE="/home/ark/esupdate.log"

if [ -f "$LOG_FILE" ]; then
  sudo rm "$LOG_FILE"
fi

wget https://github.com/christianhaitian/arkos/raw/main/Update-RK2020.sh -O /home/ark/ArkOSUpdate.sh -a "$LOG_FILE"
sudo chmod -v 777 /home/ark/ArkOSUpdate.sh | tee -a "$LOG_FILE"
sh /home/ark/ArkOSUpdate.sh

if [ $? -ne 187 ]; then
  sudo msgbox "There was an error with attempting this update.  Did you make sure to enable your wifi and connect to a wifi network?  If so, enable remote services in options and try to update again."
  printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
fi
