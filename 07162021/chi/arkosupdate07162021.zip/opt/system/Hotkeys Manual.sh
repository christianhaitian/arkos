#!/bin/bash

sudo image_viewer_controls &
image-viewer /opt/manual/CHI_hotkeys.jpg
sudo kill -9 $(pidof image_viewer_controls)
printf "\033c" >> /dev/tty1