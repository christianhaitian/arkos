#!/bin/bash

sudo killall python3