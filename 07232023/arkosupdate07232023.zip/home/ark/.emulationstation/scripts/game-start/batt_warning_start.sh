#!/bin/bash

batt_life_verbal_warning.py &