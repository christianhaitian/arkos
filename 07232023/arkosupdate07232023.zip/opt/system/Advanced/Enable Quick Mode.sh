#!/bin/bash

################################################################################################
# Thanks to stupidhoroscope for the breakdown on how this is achieved in OnionOS               #
################################################################################################

. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to enable Quick Mode?"
printf "\nPress A to continue.  Press B to exit.\n"

while true
do
   Test_Button_A
   if [ "$?" -eq "10" ]; then
	# First let's setup retroarch and retroarch32 to create autosaves and autoload savestates on game launch
	sed -i '/savestate_auto_save \=/c\savestate_auto_save \= \"true\"' /home/ark/.config/retroarch/retroarch.cfg
	sed -i '/savestate_auto_save \=/c\savestate_auto_save \= \"true\"' /home/ark/.config/retroarch32/retroarch.cfg
	sed -i '/savestate_auto_load \=/c\savestate_auto_load \= \"true\"' /home/ark/.config/retroarch/retroarch.cfg
	sed -i '/savestate_auto_load \=/c\savestate_auto_load \= \"true\"' /home/ark/.config/retroarch32/retroarch.cfg
	sed -i '/network_cmd_enable \=/c\network_cmd_enable \= \"true\"' /home/ark/.config/retroarch/retroarch.cfg
	sed -i '/network_cmd_enable \=/c\network_cmd_enable \= \"true\"' /home/ark/.config/retroarch32/retroarch.cfg

	# Then let's setup the process for shutting down retroarch and retroarch32 during the unit shutdown process
	sudo touch /usr/local/bin/quickmode.sh
	echo '#!/bin/bash' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '' | sudo tee -a /usr/local/bin/quickmode.sh
	echo 'if [[ ! -z $(pidof retroarch) ]]; then' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  pkill lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  retroarch --verbose --command QUIT' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  retroarch --verbose --command QUIT' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sudo rm -f /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  printf "%s%s%s%s\n" "#" "!" "/bin" "/bash" > /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  grep "chmod 777" /usr/local/bin/perfmax -A 3 | head -6 | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  echo "sudo run-parts /var/spool/cron/crontabs/" | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  if [[ -e /dev/shm/PNG_Loaded ]]; then' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '    echo "touch /dev/shm/PNG_Loaded" | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  fi' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  get_last_played.sh retroarch | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
        echo '  if [[ -e /dev/shm/PNG_Loaded ]]; then' | sudo tee -a /usr/local/bin/quickmode.sh
        echo '    echo "rm /dev/shm/PNG_Loaded" | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
        echo '  fi' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  grep "echo" /usr/local/bin/perfnorm -A 3 | head -6 | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sed -i "/  chmod/s//sudo chmod/" /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sed -i "/  echo/s//echo/" /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  printf "rm /home/ark/.config/lastgame.sh" | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sudo chmod 777 /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sudo chown ark:ark /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo 'elif [[ ! -z $(pidof retroarch32) ]]; then' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  pkill lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  retroarch32 --verbose --command QUIT' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  retroarch32 --verbose --command QUIT' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sudo rm -f /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  printf "%s%s%s%s\n" "#" "!" "/bin" "/bash" > /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  grep "chmod 777" /usr/local/bin/perfmax -A 3 | head -6 | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  echo "sudo run-parts /var/spool/cron/crontabs/" | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  get_last_played.sh retroarch32 | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  grep "echo" /usr/local/bin/perfnorm -A 3 | head -6 | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sed -i "/  chmod/s//sudo chmod/" /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sed -i "/  echo/s//echo/" /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  printf "rm /home/ark/.config/lastgame.sh" | tee -a /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sudo chmod 777 /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo '  sudo chown ark:ark /home/ark/.config/lastgame.sh' | sudo tee -a /usr/local/bin/quickmode.sh
	echo 'fi' | sudo tee -a /usr/local/bin/quickmode.sh
	sudo chmod 777 /usr/local/bin/quickmode.sh

	# Copy some scripts to the emulationsation game-start and game-end directories
	# to account for how retroarch treats PNG files used by the fake08 core
	cp -f /usr/local/bin/isitpng.sh /home/ark/.emulationstation/scripts/game-start/isitpng.sh
	sudo chown ark:ark /home/ark/.emulationstation/scripts/game-start/isitpng.sh
	cp -f /usr/local/bin/wasitpng.sh /home/ark/.emulationstation/scripts/game-end/wasitpng.sh
        sudo chown ark:ark /home/ark/.emulationstation/scripts/game-end/wasitpng.sh

	# Reuse the dead firstboot systemctl service for use with Quick Mode
	sudo sed -i '/ExecStart\=/c\ExecStart\=\/home\/ark\/.config\/lastgame.sh' /etc/systemd/system/firstboot.service
	sudo sed -i '/User\=root/c\User\=ark' /etc/systemd/system/firstboot.service
	sudo sed -i '/WorkingDirectory\=/c\WorkingDirectory\=\/home\/ark\/.config\/' /etc/systemd/system/firstboot.service

	# With Quick Mode, let's not hold up the hotkey deamon from starting since ES may not boot before in game
	sudo sed -i '/After\=/s//\#After\=/' /etc/systemd/system/oga_events.service
	sudo systemctl daemon-reload
	sudo systemctl enable firstboot

	# Change the shutdown script to check if retroarch is running
	sudo cp -f /usr/local/bin/finish.sh.qm /usr/local/bin/finish.sh

	#sudo sed -i '/#!\/usr\/bin\/env bash/c\#!\/usr\/bin\/env bash\ntouch \/dev\/shm\/retroarch' /usr/local/bin/retroarch
	#sudo sed -i '/#!\/usr\/bin\/env bash/c\#!\/usr\/bin\/env bash\ntouch \/dev\/shm\/retroarch32' /usr/local/bin/retroarch32

	# Replace Enable script with Disable script in Options/Advanced section
	sudo rm -f /opt/system/Advanced/"Enable Quick Mode.sh"
	cp -f /usr/local/bin/"Disable Quick Mode.sh" /opt/system/Advanced/.
	printf "\nQuick Mode is now enabled."
	sleep 3
	exit 0
   fi

   Test_Button_B
   if [ "$?" -eq "10" ]; then
      printf "\nExiting without enabling Quick Mode."
      sleep 3
      exit 0
   fi
done
