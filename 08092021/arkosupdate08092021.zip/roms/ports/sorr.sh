#!/bin/bash

cd /roms/ports/sorr
sudo ./oga_controls &
./bgdi $(find "/roms/ports/sorr" -type f -iname "sorr.dat")
sudo kill -9 $(pidof oga_controls)