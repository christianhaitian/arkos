#!/bin/bash

sudo rg351p-js2xbox --silent -t oga_joypad &
sleep 1
sudo ln -s /dev/input/event4 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
sleep 1
sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick

LOG_FILE="/home/ark/esupdate.log"

if [ -f "$LOG_FILE" ]; then
  sudo rm "$LOG_FILE"
fi

LOCATION="http://gitcdn.link/cdn/christianhaitian/arkos/main"
ISITCHINA=$(curl -s --connect-timeout 30 -m 60 http://demo.ip-api.com/json | grep -Po '"country":.*?[^\\]"')

if [[ "$ISITCHINA" == "\"country\":\"China\"" ]]; then
  printf "\n\nSwitching to China server for updates.\n\n" | tee -a "$LOG_FILE"
  LOCATION="http://139.196.213.206/arkos"
fi

wget -t 3 -T 60 --no-check-certificate "$LOCATION"/Update-RG351V.sh -O /home/ark/ArkOSUpdate.sh -a "$LOG_FILE"
sudo chmod -v 777 /home/ark/ArkOSUpdate.sh | tee -a "$LOG_FILE"
sh /home/ark/ArkOSUpdate.sh

if [ $? -ne 187 ]; then
  sudo LD_LIBRARY_PATH=/usr/local/bin msgbox "There was an error with attempting this update."
  printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
fi

sudo kill $(pidof rg351p-js2xbox)
sudo rm /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
