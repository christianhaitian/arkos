#!/bin/bash

LOG_FILE="/home/ark/esupdate.log"

if [ -f "$LOG_FILE" ]; then
  sudo rm "$LOG_FILE"
fi

LOCATION="http://gitcdn.link/cdn/christianhaitian/arkos/main"
ISITCHINA=$(curl -s --connect-timeout 30 -m 60 http://demo.ip-api.com/json | grep -Po '"country":.*?[^\\]"')

if [[ "$ISITCHINA" == "\"country\":\"China\"" ]]; then
  printf "\n\nSwitching to China server for updates.\n\n" | tee -a "$LOG_FILE"
  LOCATION="http://139.196.213.206/arkos"
fi

wget -t 3 -T 60 --no-check-certificate "$LOCATION"/Update-RGB10.sh -O /home/ark/ArkOSUpdate.sh -a "$LOG_FILE"
sudo chmod -v 777 /home/ark/ArkOSUpdate.sh | tee -a "$LOG_FILE"
sh /home/ark/ArkOSUpdate.sh

if [ $? -ne 187 ]; then
  sudo msgbox "There was an error with attempting this update.  Did you make sure to enable your wifi and connect to a wifi network?  If so, enable remote services in options and try to update again."
  printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
fi
