#!/bin/bash
sudo LD_LIBRARY_PATH=/usr/local/bin nmui
