#!/bin/bash
/opt/lzdoom/lzdoom