#!/bin/bash
/opt/VVVVVV/VVVVVV