#!/bin/bash
cd /roms/ports/Half-Life
LD_LIBRARY_PATH=. ./xash3d -fullscreen -console -sdl_joy_old_api
