#!/bin/bash
/opt/dingux/DinguxCommander