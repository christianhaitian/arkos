#!/bin/bash

if [ ! -f "linux-image-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb" ]; then
	printf "\nThe linux kernel and modules deb is missing.  Make sure linux-image-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb is located in this folder.\n"
	exit
fi
if [ ! -f "linux-headers-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb" ]; then
	printf "\nThe linux header deb is missing.  Make sure linux-headers-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb is located in this folder.\n"
	exit
fi

sudo apt update -y
sudo apt install -y ./linux-image-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb
sudo apt install -y ./linux-headers-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb
sudo apt-get install -y build-essential bc bison flex libssl-dev python
cd /usr/src/linux-headers-4.4.189-139501-g394e3e2c06b4/
wget https://raw.githubusercontent.com/armbian/build/master/patch/misc/headers-debian-byteshift.patch -O - | sudo patch -p1
sudo make scripts
cd ~
