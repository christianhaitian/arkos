#!/bin/bash

if [ ! -f "linux-image-4.4.189-139502-g380eeff98d35_4.4.189-139502-g380eeff98d35-4_arm64.deb" ]; then
	printf "\nThe linux kernel and modules deb is missing.  Make sure linux-image-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb is located in this folder.\n"
	exit
fi
if [ ! -f "linux-headers-4.4.189-139502-g380eeff98d35_4.4.189-139502-g380eeff98d35-4_arm64.deb" ]; then
	printf "\nThe linux header deb is missing.  Make sure linux-headers-4.4.189-139501-g394e3e2c06b4_4.4.189-139501-g394e3e2c06b4-7_arm64.deb is located in this folder.\n"
	exit
fi

sudo mv -v Image /boot/Image
sudo dpkg -i linux-image-4.4.189-139502-g380eeff98d35_4.4.189-139502-g380eeff98d35-4_arm64.deb
sudo dpkg -i linux-headers-4.4.189-139502-g380eeff98d35_4.4.189-139502-g380eeff98d35-4_arm64.deb
sudo mv -vf sources.list /etc/apt/sources.list
sudo chmod 644 /etc/apt/sources.list
sudo apt update -y && sudo apt-get install -y build-essential bc bison flex libssl-dev python
cd /usr/src/linux-headers-4.4.189-139502-g380eeff98d35/
wget https://raw.githubusercontent.com/armbian/build/master/patch/misc/headers-debian-byteshift.patch -O - | sudo patch -p1
sudo make scripts
sudo rm /usr/lib/modules/4.4.189/build
sudo rm /usr/lib/modules/4.4.189/source
sudo ln -s /usr/src/linux-headers-4.4.189-139502-g380eeff98d35 /usr/lib/modules/4.4.189/build
sudo ln -s /usr/src/linux-headers-4.4.189-139502-g380eeff98d35 /usr/lib/modules/4.4.189/source
cd ~
