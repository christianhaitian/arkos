#!/bin/bash
GAMEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/MalditaCastilla"
LIBDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/MalditaCastilla/lib32"

# gl4es
export LIBGL_FB=4

# system
export LD_LIBRARY_PATH=$LIBDIR:/usr/lib32:/usr/local/lib/arm-linux-gnueabihf/
export LD_PRELOAD=$LIBDIR/libbcm_host.so

cd $GAMEDIR

sudo systemctl start mchotkey.service
sudo ./rg351p-js2xbox &
./MalditaCastilla 2>&1
sudo kill $(pidof rg351p-js2xbox)
sudo systemctl stop mchotkey.service
