#!/bin/bash

sudo unzip -X -o /home/ark/rgb10kernelndtb.zip -d /
sudo depmod 4.4.189
sudo rm -v /home/ark/rgb10kernelndtb.zip
sudo mv /home/ark/root.orig /var/spool/cron/crontabs/root
rm -v -- "$0"
sudo reboot
