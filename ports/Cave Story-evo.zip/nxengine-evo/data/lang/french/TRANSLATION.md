CAVE STORY - DOUKUTSU MONOGATARI
VERSION FRANÇAISE
=================================

Jeu © Pixel 2004
Traduction par Max le Fou - 2009

Version du jeu : nxengine-evo 2.6.3

Version de la traduction : 1.2.5 (30/01/2019)

Notes de version :

1.2.5
- Correction mineure de certains caractères (Suf au lieu d'"Oeuf" etc) (fork https://github.com/B4rabbas)

1.2
- Correction des textes pour faire plus similaire avec le patch pour CS+ (Changement du tutoiement en vouvoiement)
- Traduction des crédits de fin
- Correction dans la traduction du manuel et changememnt de certains screens du manuel.

1.1
- Correction massive des textes
- Traduction de la boite de dialogue Yes/No

1.02
- Crash des crédits de fin réparé

1.01
- Shell du jeu traduit.
- Jeu compilé en installateur.
- Version Française de DoConfig.exe, renommée DoConfFR.exe. (Merci à Brendan Stephenson)
- Quelques corrections typo.

1.00
- Jeu intégralement traduit. Quelques corrections typos.
- Changé nom Iron Bond en Lien d'Acier
- Changé nom Coeur en Noyau à certains endroits

BETA 1.00
- Première release. Tout est traduit sauf le passage dans Hell

------------------------------------------

Remerciements :
- Pixel pour son super jeu :)
- la team qui a dévelopé CaveEditor
- Noxid pour son aide
- Eurower.net d'héberger mon site et la page consacrée au jeu.
- Ragax.com et miraigamer.net pour héberger mon boulot et le distribuer sur leurs sites
- toi, joueur, pour avoir downloadé et joué à ce jeu!

http://cavestory.maxlefou.com/
http://hp.vector.co.jp/authors/VA022293/
http://www.cavestorywii.com/
http://www.miraigamer.net/cavestory/
http://www.cavestory.fr/
