#!/bin/bash

whichos=$(grep "title=" "/usr/share/plymouth/themes/text.plymouth")
if [[ $whichos == *"RetroOZ"* ]]; then
  raloc="/opt/retroarch/bin"
else 
  raloc="/usr/local/bin"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  GAMEDIR="/roms2/ports/cavestory"
else
  GAMEDIR="/roms/ports/cavestory"
fi

$raloc/retroarch -L $GAMEDIR/nxengine_libretro.so $GAMEDIR/Doukutsu.exe
