#!/bin/bash

whichos=$(grep "title=" "/usr/share/plymouth/themes/text.plymouth")
if [[ $whichos == *"RetroOZ"* ]]; then
  raloc="/opt/retroarch/bin"
else 
  raloc="/usr/local/bin"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  GAMEDIR="/roms2/ports/mrboom"
else
  GAMEDIR="/roms/ports/mrboom"
fi

$raloc/retroarch -L $GAMEDIR/mrboom_libretro.so
