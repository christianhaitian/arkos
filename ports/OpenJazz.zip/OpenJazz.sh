#!/bin/bash

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
else
  param_device="chi"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  cd /roms2/ports/openjazz/
  sudo ./oga_controls OpenJazz $param_device &
  ./OpenJazz -f "$(pwd)/gamedata"
  sudo kill -9 $(pidof oga_controls)
  sudo systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
else
  cd /roms/ports/openjazz/
  sudo ./oga_controls OpenJazz $param_device &
  ./OpenJazz -f "$(pwd)/gamedata"
  sudo kill -9 $(pidof oga_controls)
  sudo systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
fi