#!/bin/bash

sudo chmod 666 /dev/tty1
export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/
printf "\033c" > /dev/tty1

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
else
  param_device="chi"
fi

sudo /roms/tools/PortMaster/oga_controls PortMaster.sh $param_device &
website="https://github.com/christianhaitian/arkos/raw/main/ports/"

ISITCHINA=$(curl -s --connect-timeout 30 -m 60 http://demo.ip-api.com/json | grep -Po '"country":.*?[^\\]"')

if [[ "$ISITCHINA" == "\"country\":\"China\"" ]]; then
  website="http://139.196.213.206/arkos/ports/"
fi

if [ ! -d "/dev/shm/portmaster" ]; then
  mkdir /dev/shm/portmaster
fi

wget -t 3 -T 60 --no-check-certificate "$website"ports.md -O /dev/shm/portmaster/ports.md

Menu() {
  msgtxt=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=Desc=").*?(?=")')
  installloc=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=locat=").*?(?=")')
  porter=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=porter=").*?(?=")')
  dialog --backtitle "PortMaster" --title "$1" --clear \
  --yesno "\n$msgtxt \n\nPorted By: $porter\n\nWould like to continue to install this port?" 15 55 2>&1 > /dev/tty1

  case $? in
     0) wget -q --show-progress "$website$installloc" -O /dev/shm/portmaster/$installloc | stdbuf -oL sed -E 's/\.\.+/---/g'| dialog --progressbox "Downloading ${1} package..." 15 55 2>&1 > /dev/tty1
        unzip -X -o /dev/shm/portmaster/$installloc -d /roms/ports/
		if [ $? -eq 0 ]; then
		  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\n$1 installed successfully." 15 55 2>&1 > /dev/tty1
		else
		  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\n$1 failed to install." 15 55 2>&1 > /dev/tty1
		fi
        sudo rm -f /dev/shm/portmaster/$installloc
	    ;;
     255) dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\nYou pressed escape? Really?" 15 55 2>&1 > /dev/tty1;;
  esac

}

userExit() {
  rm -f /dev/shm/portmaster/ports.md
  sudo kill -9 $(pidof oga_controls)
  exit 0
}

MainMenu() {
  local options=(
   $(cat /dev/shm/portmaster/ports.md | grep -oP '(?<=Title=").*?(?=")')
  )
  local options2=(
    $(cat /dev/shm/portmaster/ports.md | grep -oP '(?<=Desc=").*?(?=")')
  )

  while true; do
    selection=(dialog \
   	--backtitle "PortMaster $1" \
   	--title "[ Main Menu ]" \
   	--no-collapse \
   	--clear \
	--cancel-label "Select + Start to Exit" \
        --menu "$2" 15 55 15)

    choices=$("${selection[@]}" "${options[@]}" 2>&1 > /dev/tty1) || userExit

    for choice in $choices; do
      case $choice in
        *) Menu $choice ;;
      esac
    done
  done
}

MainMenu "$1" "$2"

