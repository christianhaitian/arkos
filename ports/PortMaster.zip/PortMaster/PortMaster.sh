#!/bin/bash

sudo chmod 666 /dev/tty1
export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/
printf "\033c" > /dev/tty1

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
else
  param_device="chi"
fi

sudo /opt/system/Tools/PortMaster/oga_controls PortMaster.sh $param_device &

GW=`ip route | awk '/default/ { print $3 }'`
if [ -z "$GW" ]; then
  dialog --backtitle "PortMaster" --title "$1" --clear \
  --msgbox "\n\nYour network connection doesn't seem to be working. \
  \nDid you make sure to configure your wifi connection?" 15 55 2>&1 > /dev/tty1
  sudo kill -9 $(pidof oga_controls)
  sudo systemctl restart oga_events &
  exit 0
fi

website="https://github.com/christianhaitian/arkos/raw/main/ports/"

ISITCHINA=$(curl -s --connect-timeout 30 -m 60 http://demo.ip-api.com/json | grep -Po '"country":.*?[^\\]"')

if [[ "$ISITCHINA" == "\"country\":\"China\"" ]]; then
  website="http://139.196.213.206/arkos/ports/"
fi

if [ ! -d "/dev/shm/portmaster" ]; then
  mkdir /dev/shm/portmaster
fi

dpkg -s "curl" &>/dev/null

if [ "$?" != "0" ]; then
  sudo apt update && sudo apt install -y curl --no-install-recommends
fi

UpdateCheck() {

  if [[ "$website" == "http://139.196.213.206/arkos/ports/" ]]; then
    gitversion=$(curl -s --connect-timeout 30 -m 60 http://139.196.213.206/arkos/ports/version)
  else
    gitversion=$(curl -s --connect-timeout 30 -m 60 https://raw.githubusercontent.com/christianhaitian/arkos/main/ports/version)
  fi

  if [[ "$gitversion" != "$(curl file:///opt/system/Tools/PortMaster/version)" ]]; then
    wget -q --show-progress "${website}PortMaster.zip" -O /dev/shm/portmaster/PortMaster.zip | stdbuf -oL sed -E 's/\.\.+/---/g'| dialog \
          --progressbox "Downloading and installing PortMaster update..." 15 55 2>&1 > /dev/tty1
    unzip -X -o /dev/shm/portmaster/PortMaster.zip -d /opt/system/Tools/
	if [ $? -eq 0 ]; then
	  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\nPortMaster updated successfully." 15 55 2>&1 > /dev/tty1
	  echo $gitversion > /opt/system/Tools/PortMaster/version
	  sudo kill -9 $(pidof oga_controls)
	  sudo rm -f /dev/shm/portmaster/PortMaster.zip
	  sudo systemctl restart oga_events &
	  exit 0
	else
	  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\nPortMaster failed to update." 15 55 2>&1 > /dev/tty1
	  sudo rm -f /dev/shm/portmaster/PortMaster.zip
	fi
  else
    dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\nNo update needed." 15 55 2>&1 > /dev/tty1
  fi
}

wget -t 3 -T 60 --no-check-certificate "$website"ports.md -O /dev/shm/portmaster/ports.md

PortInfoInstall() {
  if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
    whichsd="roms2"
  else
    whichsd="roms"
  fi
  
  msgtxt=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=Desc=").*?(?=")')
  installloc=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=locat=").*?(?=")')
  porter=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=porter=").*?(?=")')
  dialog --backtitle "PortMaster" --title "$1" --clear \
  --yesno "\n$msgtxt \n\nPorted By: $porter\n\nWould you like to continue to install this port?" 15 55 2>&1 > /dev/tty1

  case $? in
     0) wget -q --show-progress "$website$installloc" -O \
	    /dev/shm/portmaster/$installloc | stdbuf -oL sed -E 's/\.\.+/---/g'| dialog --progressbox \
		"Downloading ${1} package..." 15 55 2>&1 > /dev/tty1
        unzip -X -o /dev/shm/portmaster/$installloc -d /$whichsd/ports/
		if [ $? -eq 0 ]; then
		  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\n$1 installed successfully. \
		  \n\nMake sure to restart EmulationStation in order to see it in the ports menu." 15 55 2>&1 > /dev/tty1
		else
		  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\n$1 failed to install." 15 55 2>&1 > /dev/tty1
		fi
        sudo rm -f /dev/shm/portmaster/$installloc
	    ;;
  esac
}

userExit() {
  rm -f /dev/shm/portmaster/ports.md
  sudo kill -9 $(pidof oga_controls)
  sudo systemctl restart oga_events &
  exit 0
}

MainMenu() {
  local options=(
   $(cat /dev/shm/portmaster/ports.md | grep -oP '(?<=Title=").*?(?=")')
  )

  while true; do
    selection=(dialog \
   	--backtitle "PortMaster" \
   	--title "[ Main Menu ]" \
   	--no-collapse \
   	--clear \
	--cancel-label "Select + Start to Exit" \
    --menu "Available ports for install" 15 55 15)

    choices=$("${selection[@]}" "${options[@]}" 2>&1 > /dev/tty1) || userExit

    for choice in $choices; do
      case $choice in
        *) PortInfoInstall $choice ;;
      esac
    done
  done
}

dialog --backtitle "PortMaster" --title "$1" --clear \
--yesno "\nWould you like to check for an update to the PortMaster tool?" 15 55 2>&1 > /dev/tty1

  case $? in
     0) UpdateCheck;;
  esac

MainMenu

