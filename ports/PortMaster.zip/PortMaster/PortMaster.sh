#!/bin/bash

sudo chmod 666 /dev/tty1
export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/
printf "\033c" > /dev/tty1

hotkey="Select"
height="15"
width="55"

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
	  hotkey="Minus"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
  hotkey="Select"
else
  param_device="chi"
  hotkey="1"
  height="20"
  width="60"
fi

sudo /opt/system/Tools/PortMaster/oga_controls PortMaster.sh $param_device &

GW=`ip route | awk '/default/ { print $3 }'`
if [ -z "$GW" ]; then
  dialog --backtitle "PortMaster v$curversion" --title "$1" --clear \
  --msgbox "\n\nYour network connection doesn't seem to be working. \
  \nDid you make sure to configure your wifi connection?" $height $width 2>&1 > /dev/tty1
  sudo kill -9 $(pidof oga_controls)
  sudo systemctl restart oga_events &
  exit 0
fi

curversion="$(curl file:///opt/system/Tools/PortMaster/version)"

website="https://github.com/christianhaitian/arkos/raw/main/ports/"

ISITCHINA=$(curl -s --connect-timeout 30 -m 60 http://demo.ip-api.com/json | grep -Po '"country":.*?[^\\]"')

if [[ "$ISITCHINA" == "\"country\":\"China\"" ]]; then
  website="http://139.196.213.206/arkos/ports/"
fi

if [ ! -d "/dev/shm/portmaster" ]; then
  mkdir /dev/shm/portmaster
fi

dpkg -s "curl" &>/dev/null
if [ "$?" != "0" ]; then
  sudo apt update && sudo apt install -y curl --no-install-recommends
fi

dpkg -s "dialog" &>/dev/null
if [ "$?" != "0" ]; then
  sudo apt update && sudo apt install -y dialog --no-install-recommends
  temp=$(grep "title=" /usr/share/plymouth/themes/text.plymouth)
  if [[ $temp == *"ArkOS 351P/M"* ]]; then
	#Make sure sdl2 wasn't impacted by the install of dialog for the 351P/M
    sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.14.1 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
	sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.10.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
  fi
fi

UpdateCheck() {

  if [[ "$website" == "http://139.196.213.206/arkos/ports/" ]]; then
    gitversion=$(curl -s --connect-timeout 30 -m 60 http://139.196.213.206/arkos/ports/version)
  else
    gitversion=$(curl -s --connect-timeout 30 -m 60 https://raw.githubusercontent.com/christianhaitian/arkos/main/ports/version)
  fi

  if [[ "$gitversion" != "$curversion" ]]; then
    wget -q --show-progress "${website}PortMaster.zip" -O /dev/shm/portmaster/PortMaster.zip | stdbuf -oL sed -E 's/\.\.+/---/g'| dialog \
          --progressbox "Downloading and installing PortMaster update..." $height $width 2>&1 > /dev/tty1
    unzip -X -o /dev/shm/portmaster/PortMaster.zip -d /opt/system/Tools/
	if [ $? -eq 0 ]; then
	  dialog --backtitle "PortMaster" --title "$1" --clear --msgbox "\n\nPortMaster updated successfully." $height $width 2>&1 > /dev/tty1
	  echo $gitversion > /opt/system/Tools/PortMaster/version
	  sudo kill -9 $(pidof oga_controls)
	  sudo rm -f /dev/shm/portmaster/PortMaster.zip
	  sudo systemctl restart oga_events &
	  exit 0
	else
	  dialog --backtitle "PortMaster v$curversion" --title "$1" --clear --msgbox "\n\nPortMaster failed to update." $height $width 2>&1 > /dev/tty1
	  sudo rm -f /dev/shm/portmaster/PortMaster.zip
	fi
  else
    dialog --backtitle "PortMaster v$curversion" --title "$1" --clear --msgbox "\n\nNo update needed." $height $width 2>&1 > /dev/tty1
  fi
}

wget -t 3 -T 60 --no-check-certificate "$website"ports.md -O /dev/shm/portmaster/ports.md

PortInfoInstall() {
  if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
    whichsd="roms2"
  else
    whichsd="roms"
  fi
  
  msgtxt=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=Desc=").*?(?=")')
  installloc=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=locat=").*?(?=")')
  porter=$(cat /dev/shm/portmaster/ports.md | grep "$1" | grep -oP '(?<=porter=").*?(?=")')
  dialog --backtitle "PortMaster v$curversion" --title "$1" --clear \
  --yesno "\n$msgtxt \n\nPorted By: $porter\n\nWould you like to continue to install this port?" $height $width 2>&1 > /dev/tty1

  case $? in
     0) wget -q --show-progress "$website$installloc" -O \
	    /dev/shm/portmaster/$installloc | stdbuf -oL sed -E 's/\.\.+/---/g'| dialog --progressbox \
		"Downloading ${1} package..." $height $width 2>&1 > /dev/tty1
        unzip -X -o /dev/shm/portmaster/$installloc -d /$whichsd/ports/
		if [ $? -eq 0 ]; then
		  dialog --backtitle "PortMaster v$curversion" --title "$1" --clear --msgbox "\n\n$1 installed successfully. \
		  \n\nMake sure to restart EmulationStation in order to see it in the ports menu." $height $width 2>&1 > /dev/tty1
		else
		  dialog --backtitle "PortMaster v$curversion" --title "$1" --clear --msgbox "\n\n$1 failed to install." $height $width 2>&1 > /dev/tty1
		fi
        sudo rm -f /dev/shm/portmaster/$installloc
	    ;;
  esac
}

userExit() {
  rm -f /dev/shm/portmaster/ports.md
  sudo kill -9 $(pidof oga_controls)
  sudo systemctl restart oga_events &
  exit 0
}

MainMenu() {
  local options=(
   $(cat /dev/shm/portmaster/ports.md | grep -oP '(?<=Title=").*?(?=")')
  )

  while true; do
    selection=(dialog \
   	--backtitle "PortMaster v$curversion" \
   	--title "[ Main Menu ]" \
   	--no-collapse \
   	--clear \
	--cancel-label "$hotkey + Start to Exit" \
    --menu "Available ports for install" $height $width 15)

    choices=$("${selection[@]}" "${options[@]}" 2>&1 > /dev/tty1) || userExit

    for choice in $choices; do
      case $choice in
        *) PortInfoInstall $choice ;;
      esac
    done
  done
}

dialog --backtitle "PortMaster v$curversion" --title "$1" --clear \
--yesno "\nWould you like to check for an update to the PortMaster tool?" $height $width 2>&1 > /dev/tty1

  case $? in
     0) UpdateCheck;;
  esac

MainMenu

